import React from "react";
import "./report.css";
const Report = () => {
  return <div>Report</div>;
};

export default Report;
